aclocal
libtoolize
automake --add-missing
autoconf
