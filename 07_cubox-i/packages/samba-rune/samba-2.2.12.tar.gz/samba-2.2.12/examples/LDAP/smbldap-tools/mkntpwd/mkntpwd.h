#include <memory.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

typedef short int16;
typedef int int32;
typedef unsigned short uint16;
typedef unsigned int uint32;
typedef unsigned char uchar;

#define MAX_STRING 255
#define MAX_WORD 128
#define LMPASSWDLEN 14
#define NTPASSWDLEN 128
#define FILENAMEBUFFER 128
